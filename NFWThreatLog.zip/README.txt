Content
Sources: [Network Firewall  Threat Log]
Parsers: [NFW Threat Log]
Fields: [DestinationUser, SourceUser]

Reference
Functions: [Geolocation]
Fields: [actn, cityclnt, cloudevntsver, collectiontime, compartmentid, continentclnt, continentcodeclnt, countryclnt, countrycodeclnt, destip, dev, geolocclnt, loggingloggrpocid, logginglogocid, loggingrecid, mbody, ocirsrcname, regionclnt, regioncodeclnt, sevlvl, srcip, tenant, threatcat, threateventid, time, tranprot, type]
