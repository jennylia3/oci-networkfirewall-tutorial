Content
Sources: [Network Firewall Traffic Log]
Parsers: [NFW Traffic Log]
Fields: [Bytes, Bytes Sent, BytesReceived]

Reference
Functions: [Geolocation]
Fields: [actn, cityclnt, cloudevntsver, collectiontime, compartmentid, continentclnt, continentcodeclnt, countryclnt, countrycodeclnt, destip, destport, dev, geolocclnt, loggingloggrpocid, logginglogocid, loggingrecid, mbody, ocirsrcname, regionclnt, regioncodeclnt, srcip, srcport, tenant, time, tranprot, type]
